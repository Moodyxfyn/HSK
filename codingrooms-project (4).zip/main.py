#Intro to the game.

print('Welcome to, Console Mandarin HSK 1 **MOCK TEST**')

#make the player type their name

playing = input ("Please Type Your Name. ")
print (playing)
yes_no = input ('Is this your name? ')
if yes_no == 'yes':
    ()
else:
    playing = input ('Please type your name! ')

#now here is where the test begins.

test = input ('What does 再见 mean? ')
if test == 'goodbye':
    ()
else:
   print ('sorry. the anwser is, goodbye')